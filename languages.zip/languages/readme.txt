For creating translation file
=============================

1. Copy the "wedevs-project-manager.pot" file to "wedevs-project-manager-<YOUR_LANGUAGE_CODE>.po". e.g: "wedevs-project-manager-fr_FR.po"
2. Open the "wedevs-project-manager-<YOUR_LANGUAGE_CODE>.po" in "Poedit" software and translate the strings.
